module.exports = async (client, node, reason) => {
	console.log("[🔴] Lavalink / Node Disconnected Reason; " + reason)
}