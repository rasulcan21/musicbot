module.exports = async (client, node) => {
	console.log("[🟢] Lavalink / Node Player!")
}